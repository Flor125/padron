package elecciones;

import elecciones.Elecciones;
import Clases.conectar;
import java.sql.Connection;
import javax.swing.ButtonGroup;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import java.sql.DriverManager;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Candidatos extends javax.swing.JFrame {
    private static conectar con;
    public static final String driver = "com.mysql.jdbc.Driver";
    public static final String url = "jdbc:mysql://localhost:3308/padron";
    public static final String usuario = "root";
    public static final String contraseña = "";
    ButtonGroup grupoBotones; 
    private String candidatoSeleccionado;
    private javax.swing.JLabel labelNombre;
    private javax.swing.JLabel labelPartido;
    private javax.swing.JLabel labelLista;
    public int dniVotante;
    
    
     public int convertirDNANumero(String dni) {
    try {
        
        return Integer.parseInt(dni);
    } catch (NumberFormatException e) {
        return -1; // Valor inválido
    }
}
    
    public Candidatos(int dni) {
    initComponents();
    dniVotante = dni; 
}
    public void setDNI(String dni) {
        disableDNI.setText(dni);
    }
    
    
    public Candidatos() {
        initComponents();
        grupoBotones = new ButtonGroup();
            grupoBotones.add(jRadioButton1);
            grupoBotones.add(jRadioButton2);
            grupoBotones.add(jRadioButton3);
            grupoBotones.add(jRadioButton4);
            grupoBotones.add(jRadioButton5);
        
            labelNombre = new javax.swing.JLabel();
            labelPartido = new javax.swing.JLabel();
            labelLista = new javax.swing.JLabel();
    }
    
    private void cargarDatosCandidato(int candidatoId) {

    try (Connection conexion = DriverManager.getConnection(url, usuario, contraseña)) {
        String consulta = "SELECT NOMBRE, PARTIDO, LISTA FROM presidente WHERE ID = ?";
        try (PreparedStatement preparedStatement = conexion.prepareStatement(consulta)) {
            preparedStatement.setInt(1, candidatoId);
            try (ResultSet resultado = preparedStatement.executeQuery()) {
                if (resultado.next()) {
                    String nombre = resultado.getString("NOMBRE");
                    String partido = resultado.getString("PARTIDO");
                    String lista = resultado.getString("LISTA");

                    // ETIQUETAS
                    labelNombre.setText("NOMBRE: " + nombre);
                    labelPartido.setText("PARTIDO: " + partido);
                    labelLista.setText("LISTA: " + lista);
                }
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar datos desde la base de datos: " + e.getMessage());
    }
}

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton5 = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        votebotton = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        disableDNI = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jLabel1.setText("Elecciones 2023");

        jLabel2.setText("Presidentes");

        jRadioButton1.setText("Javier Milei");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        jRadioButton2.setText("Sergio Massa");

        jRadioButton3.setText("Patricia Bullrich");

        jRadioButton4.setText("Juan Schiaretti");

        jRadioButton5.setText("Myriam Bregman");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        jLabel3.setText("Libertad Avanza");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        jLabel5.setText("Unión por la Patria");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        jLabel6.setText("Juntos por el Cambio");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        jLabel7.setText("Hacemos por nuestro país");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        jLabel8.setText("Frente de Izquierda");

        votebotton.setText("Votar");
        votebotton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                votebottonActionPerformed(evt);
            }
        });

        jLabel4.setText("DNI Registrado:");

        disableDNI.setEnabled(false);
        disableDNI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                disableDNIActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(disableDNI, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 63, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jRadioButton2)
                    .addComponent(jRadioButton3)
                    .addComponent(jRadioButton5)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton4)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3)
                            .addComponent(jLabel8)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(votebotton)))
                    .addComponent(jLabel1))
                .addGap(37, 37, 37))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel1)
                                .addComponent(jLabel2))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(jLabel4)))
                        .addGap(27, 27, 27)
                        .addComponent(jRadioButton1)
                        .addGap(4, 4, 4))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(disableDNI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(votebotton)
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        // TODO add your handling code here:

    if (jRadioButton1.isSelected()) {
        cargarDatosCandidato(1);
        } else if (jRadioButton2.isSelected()) {
            cargarDatosCandidato(2);
            } else if (jRadioButton3.isSelected()) {
                cargarDatosCandidato(3);
                } else if (jRadioButton4.isSelected()) {
                    cargarDatosCandidato(4);
                    } else if (jRadioButton5.isSelected()) {
                        cargarDatosCandidato(5);
                    }
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private String obtenerCandidatoSeleccionado() {
    if (jRadioButton1.isSelected()) {
        return jRadioButton1.getText();
    } else if (jRadioButton2.isSelected()) {
        return jRadioButton2.getText();
    } else if (jRadioButton3.isSelected()) {
        return jRadioButton3.getText();
    } else if (jRadioButton4.isSelected()) {
        return jRadioButton4.getText();
    } else if (jRadioButton5.isSelected()) {
        return jRadioButton5.getText();
    }
    return null; //SI NO SE SELECCIONA EL CANDIDATO.
}
    
    private void votebottonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_votebottonActionPerformed
        // TODO add your handling code here:
        candidatoSeleccionado = obtenerCandidatoSeleccionado();

    if (candidatoSeleccionado != null && !candidatoSeleccionado.isEmpty()) {
        if (dniVotante > 0) {
            JOptionPane.showMessageDialog(this, "Ya has votado a: " + candidatoSeleccionado);
        } else {
            int idCandidato = obtenerIdCandidato(candidatoSeleccionado);

            if (idCandidato > 0) {
                registrarVotoEnBaseDeDatos();

                JOptionPane.showMessageDialog(this, "Has votado a: " + candidatoSeleccionado);

                votebotton.setEnabled(false);

                dniVotante = 12345678; // Reemplaza esto con el DNI del votante
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró el ID del candidato.");
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Por favor, selecciona un candidato antes de votar.");
    }

    }//GEN-LAST:event_votebottonActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        
    }//GEN-LAST:event_formWindowActivated

    private void disableDNIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_disableDNIActionPerformed
        // TODO add your handling code here:
        String dni = disableDNI.getText();
        setDNI(dni);
        setDNI(dni);
    }//GEN-LAST:event_disableDNIActionPerformed

    private int obtenerIdCandidato(String nombreCandidato) {
    int idCandidato = -1;

    try (Connection conexion = DriverManager.getConnection(url, usuario, contraseña)) {
        String sql = "SELECT ID FROM presidente WHERE NOMBRE = ?";
        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setString(1, nombreCandidato);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    idCandidato = resultSet.getInt("ID");
                }
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos: " + e.getMessage());
    }
    return idCandidato;
}    
    private String obtenerDatosCandidato(String nombreCandidato) {

    // Inicializa la variable que almacenará los datos del candidato
    String datosCandidato = "";

    try (Connection conexion = DriverManager.getConnection(url, usuario, contraseña)) {
        // Consulta SQL para obtener los datos del candidato seleccionado
        String consulta = "SELECT NOMBRE, PARTIDO, LISTA FROM presidente WHERE NOMBRE = ?";
        try (PreparedStatement preparedStatement = conexion.prepareStatement(consulta)) {
            preparedStatement.setString(1, nombreCandidato);
            try (ResultSet resultado = preparedStatement.executeQuery()) {
                if (resultado.next()) {
                    String nombre = resultado.getString("NOMBRE");
                    String partido = resultado.getString("PARTIDO");
                    String lista = resultado.getString("LISTA");

                    // Formatea los datos del candidato
                    datosCandidato = "NOMBRE: " + nombre + "\nPARTIDO: " + partido + "\nLISTA: " + lista;
                }
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar datos desde la base de datos: " + e.getMessage());
    }

    return datosCandidato;
}
    private void registrarVotoEnBaseDeDatos() {

    try (Connection conexion = DriverManager.getConnection(url, usuario, contraseña)) {
        String sql = "INSERT INTO votacion (DNI, PARTIDO, FECHA_HORA) VALUES (?, ?, NOW())";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setInt(1, dniVotante);
            preparedStatement.setString(2, candidatoSeleccionado);

            int filasAfectadas = preparedStatement.executeUpdate();
            if (filasAfectadas > 0) {
                JOptionPane.showMessageDialog(this, "¡Voto registrado con éxito!");
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar el voto.");
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos: " + e.getMessage());
    }

}
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Candidatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Candidatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Candidatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Candidatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Candidatos().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField disableDNI;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JButton votebotton;
    // End of variables declaration//GEN-END:variables
}
